package com.techm.ms.resource;

import static org.junit.Assert.assertEquals;

import org.apache.http.HttpResponse;
import org.apache.http.HttpResponseFactory;
import org.apache.http.HttpStatus;
import org.apache.http.HttpVersion;
import org.apache.http.impl.DefaultHttpResponseFactory;
import org.apache.http.message.BasicStatusLine;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.techm.ms.model.UserResponse;

@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UserResourceTest {

	UserResponse userResponse;
	// static UserResponse userResponse;
	HttpResponse httpResponse;
	HttpResponseFactory factory;

	@Before
	public void setUp() throws Exception {
		userResponse = new UserResponse();
		userResponse = new UserResponse();
		factory = new DefaultHttpResponseFactory();
		httpResponse = factory.newHttpResponse(new BasicStatusLine(HttpVersion.HTTP_1_1, HttpStatus.SC_OK, null), null);
	}

	@Ignore
	public void testCreateUser_success() {
		UserResource userResources = new UserResourceImpl();
		httpResponse.setStatusCode(201);
		httpResponse.setReasonPhrase("New user was created");
		userResponse.setHttpResponse(httpResponse);
		System.out.println("response-"+ userResources.createUser(1, "Raghu", 35, 200).getHttpResponse());
		System.out.println("responsemine-"+ userResponse.getHttpResponse());
		assertEquals(userResponse.getHttpResponse(), userResources.createUser(1, "Raghu", 35, 200).getHttpResponse());
	}

	@Ignore
	public void testCreateUser_failure() {
		UserResource userResources = new UserResourceImpl();
		httpResponse.setStatusCode(409);
		httpResponse.setReasonPhrase("unable to Create. A Account with name already exist");
		userResponse.setHttpResponse(httpResponse);
		assertEquals(userResponse, userResources.createUser(1, "Raghu", 35, 200));
	}

	@Ignore
	public void testGetUser_success() {
		UserResource userResources = new UserResourceImpl();
		httpResponse.setStatusCode(200);
		httpResponse.setReasonPhrase("User Exists");
		userResponse.setHttpResponse(httpResponse);
		assertEquals(userResponse, userResources.getUser(1));
	}

	@Ignore
	public void testGetUser_failure() {
		UserResource userResources = new UserResourceImpl();
		httpResponse.setStatusCode(404);
		httpResponse.setReasonPhrase("404: Account with id " + 1 + " not found");
		userResponse.setHttpResponse(httpResponse);
		assertEquals(userResponse, userResources.getUser(1));
	}
}
