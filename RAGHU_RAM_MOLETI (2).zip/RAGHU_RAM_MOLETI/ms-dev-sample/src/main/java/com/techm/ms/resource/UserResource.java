package com.techm.ms.resource;

import com.techm.ms.model.UserResponse;

/**
 * This is the Interface definition for User Resource
 * 
 */
public interface UserResource {

	public UserResponse createUser(long id, String name, int age, int accountId);

	public UserResponse getUser(long userId);

}