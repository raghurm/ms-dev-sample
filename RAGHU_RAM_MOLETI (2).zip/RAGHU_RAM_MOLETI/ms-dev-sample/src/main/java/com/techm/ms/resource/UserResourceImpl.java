package com.techm.ms.resource;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpResponseFactory;
import org.apache.http.HttpStatus;
import org.apache.http.HttpVersion;
import org.apache.http.impl.DefaultHttpResponseFactory;
import org.apache.http.message.BasicStatusLine;
import org.springframework.stereotype.Controller;

import com.techm.ms.model.User;
import com.techm.ms.model.UserResponse;

@Controller
public class UserResourceImpl implements UserResource {

	static List<User> usersList;
	static UserResponse userResponse;
	HttpResponse httpResponse;
	HttpResponseFactory factory;

	UserResourceImpl() {
		usersList = new ArrayList<User>();
		factory = new DefaultHttpResponseFactory();
	}

	/**
	 * @param id
	 * @param name
	 * @param age
	 * @param accountId
	 * @return UserResponse
	 */
	public UserResponse createUser(long id, String name, int age, int accountId) {
		boolean userExists = false;
		userResponse = new UserResponse();
		httpResponse = factory.newHttpResponse(new BasicStatusLine(HttpVersion.HTTP_1_1, HttpStatus.SC_OK, null), null);
		try {
			for (User user : usersList) {
				if (null != name && name.equalsIgnoreCase(user.getName())) {
					userExists = true;
				}
				if (userExists) {
					break;
				}
			}
			if (userExists) {
				httpResponse.setStatusCode(409);
				httpResponse.setReasonPhrase("unable to Create. A Account with name already exist");
				userResponse.setHttpResponse(httpResponse);
			} else {
				usersList.add(new User(id, name, age, accountId));
				if (null != getUser(id)) {
					httpResponse.setStatusCode(201);
					httpResponse.setReasonPhrase("New user was created");
					userResponse.setHttpResponse(httpResponse);
				}
			} 
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return userResponse;
	}

	/**
	 * 
	 * @param userId
	 * @return UserResponse
	 */
	public UserResponse getUser(long userId) {
		boolean userExists = false;
		userResponse = new UserResponse();
		httpResponse = factory.newHttpResponse(new BasicStatusLine(HttpVersion.HTTP_1_1, HttpStatus.SC_OK, null), null);
		try {
			for (User user : usersList) {
				if (user.getId() == userId) {
					httpResponse.setStatusCode(200);
					httpResponse.setReasonPhrase("User Exists");
					userResponse.setHttpResponse(httpResponse);
					userResponse.setUser(user);
					userExists = true;
				}
				if (userExists) {
					break;
				}
			}
			if (!userExists) {
				httpResponse.setStatusCode(404);
				httpResponse.setReasonPhrase("404: Account with id " + userId + " not found");
				userResponse.setHttpResponse(httpResponse);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userResponse;
	}
}
